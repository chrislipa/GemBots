Contributors to Gem Bots Mac OS X Implementation
================================================


PROGRAMMING:
------------------------
Christopher Lipa
    chrislipa@gmail.com



SPECIFICATION DESIGN:
------------------------
David Underhill  
    dgu@cs.stanford.edu
    http://dound.com/

Christopher Lipa  
    chrislipa@gmail.com




Inspired by and heavily based upon:
-----------------------------------
    AT Robots 2, by 
    Ed T. Toton III
    NecroBones Enterprises 
    http://necrobones.com/atrobots/
    necrobones@necrobones.com


