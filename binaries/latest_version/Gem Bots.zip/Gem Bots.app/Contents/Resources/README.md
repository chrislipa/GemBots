Gem Bots
========

Gem Bots pits autonomous virtual tanks against each other in a deadly free-for-all competition.  Players outfit their tanks with customized armaments, and impart strategy and tactics by programming the tank’s onboard computer using a simple, low-level language.  Battles take place in a two-dimensional battleground moderated by the Gem Bots Simulator.